<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>  -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous"> -->
    <!-- css lokal -->
    <link rel="styleshet" href="gaya.css">

    <!-- judul -->
    <title>Input Data Guru</title>
    <style>
        body {
            background-image: url(https://sorongselatan.bawaslu.go.id/wp-content/uploads/2020/08/Background-opera-speeddials-community-web-simple-backgrounds.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <!-- page bawahnya -->
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <h1> Daftar Data Guru </h1>
        </div>
        <div class="container">
            <!-- ini nambah tombol kelola guru -->
            <a href="<?php

use App\Controllers\control_guru;

echo base_url('control_guru/kelolaguru') ?>" class="btn btn-success mt-3">Tambah Guru</a>
            <!-- buat nambah flash data -->
            <?php if (session()->getFlashdata('pesan')) : ?>
                <div class="alert alert-success mt-2" role="alert">
                    <?= session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif; ?>
            <script>
                // Basic example
                $(document).ready(function() {
                    $('#dtBasicExample').DataTable({
                        "searching": false // false to disable search (or any other option)
                    });
                    $('.dataTables_length').addClass('bs-select');
                });
            </script>
            <div>
                <table class="table table-striped table-bordered table-sm mt-2" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th scope="col">id_guru</th>
                            <th scope="col">NIP</th>
                            <th scope="col">Username</th>
                            <th scope="col">Nama Guru</th>
                            <th scope="col">Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($guru as $g) :  ?>
                            <tr>
                                <th><?= $g['id_guru']; ?></th>
                                <td><?= $g['NIP']; ?></td>
                                <td><?= $g['username']; ?></td>
                                <td><?= $g['nama_guru']; ?></td>
                                <td><?= $g['email']; ?></td>
                                <td><a href="<?php echo base_url('control_guru/delete_guru/'. $g['id_guru']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin ?')">Hapus</a></td>
                                <td><a class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?php echo $g['id_guru']; ?>" >edit</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col md-6">
                    <a class="btn btn-warning btn-block mt-2" href="<?php echo base_url('/pages') ?>">Kembali</a>
                </div>
            </div>
        </div>
    </div>

    <!-- modals -->
    <?php foreach ($guru as $g): ?>
        <div class="modal fade" id="edit<?php echo $g['id_guru']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel23">Edit Guru</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row g-3" action="<?php echo base_url('control_guru/update_guru'); ?>" method="post">
                            <div class="form-group">
                                <input type="hidden" class="form-control"  name="id" value="<?php echo $g['id_guru'] ?>">
                                <label for="nama">Masukan nama guru</label>
                                <input type="text" class="form-control" placeholder="Nama guru" id="nama" name="nama" value="<?php echo $g['nama_guru'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="nip">Masukan NIP</label>
                                <input type="text" class="form-control" placeholder="NIP" id="nip" name="nip" value="<?php echo $g['NIP'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Masukan Email</label>
                                <input type="email" class="form-control" placeholder="email" id="email" name="email" value="<?php echo $g['email'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="username">Masukan Username</label>
                                <input type="text" class="form-control" placeholder="Username" id="username" name="username" value="<?php echo $g['username'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="password">Masukan Password</label>
                                <input type="password" class="form-control" placeholder="password"  id="password" name="password" value="<?php echo $g['password'] ?>" readonly>
                            </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script> -->
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
</body>

